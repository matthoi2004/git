﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CampingApp.Data;
using CampingApp.Models;

namespace CampingApp.Controllers.Api
{
    [ApiController]
    [Route("api/[controller]")]
    public class BetalingsController : ControllerBase
    {
        private readonly CampingContext _context;

        public BetalingsController(CampingContext context)
        {
            _context = context;
        }

        // GET: api/Betalings
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Betaling>>> GetAll()
        {
            return await _context.Betalingen.ToListAsync();
        }

        // GET: api/Betalings/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Betaling>> GetById(int id)
        {
            var betaling = await _context.Betalingen.FindAsync(id);

            if (betaling == null)
                return NotFound();

            return betaling;
        }

        // POST: api/Betalings
        [HttpPost]
        public async Task<ActionResult<Betaling>> Create(Betaling betaling)
        {
            _context.Betalingen.Add(betaling);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(GetById),
                new { id = betaling.BetalingId },
                betaling
            );
        }

        // PUT: api/Betalings/5
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, Betaling betaling)
        {
            if (id != betaling.BetalingId)
                return BadRequest();

            _context.Entry(betaling).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BetalingExists(id))
                    return NotFound();

                throw;
            }

            return NoContent();
        }

        // DELETE: api/Betalings/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var betaling = await _context.Betalingen.FindAsync(id);

            if (betaling == null)
                return NotFound();

            _context.Betalingen.Remove(betaling);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool BetalingExists(int id)
        {
            return _context.Betalingen.Any(e => e.BetalingId == id);
        }
    }
}
