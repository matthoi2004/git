﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CampingApp.Data;
using CampingApp.Models;

namespace CampingApp.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    public class FacturenController : ControllerBase
    {
        private readonly CampingContext _context;

        public FacturenController(CampingContext context)
        {
            _context = context;
        }

        // GET: api/Facturen
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Factuur>>> GetFacturen()
        {
            return await _context.Facturen.ToListAsync();
        }

        // GET: api/Facturen/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Factuur>> GetFactuur(int id)
        {
            var factuur = await _context.Facturen.FindAsync(id);

            if (factuur == null)
            {
                return NotFound();
            }

            return factuur;
        }

        // POST: api/Facturen
        [HttpPost]
        public async Task<ActionResult<Factuur>> CreateFactuur(Factuur factuur)
        {
            _context.Facturen.Add(factuur);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetFactuur), new { id = factuur.FactuurNummerID }, factuur);
        }

        // PUT: api/Facturen/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateFactuur(int id, Factuur factuur)
        {
            if (id != factuur.FactuurNummerID)
            {
                return BadRequest();
            }

            _context.Entry(factuur).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!FactuurExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: api/Facturen/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteFactuur(int id)
        {
            var factuur = await _context.Facturen.FindAsync(id);
            if (factuur == null)
            {
                return NotFound();
            }

            _context.Facturen.Remove(factuur);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool FactuurExists(int id)
        {
            return _context.Facturen.Any(e => e.FactuurNummerID == id);
        }
    }
}

