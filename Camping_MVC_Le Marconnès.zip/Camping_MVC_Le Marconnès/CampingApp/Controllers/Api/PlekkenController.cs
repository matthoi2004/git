﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CampingApp.Data;
using CampingApp.Models;

namespace CampingApp.Controllers.Api
{
    [ApiController]
    [Route("api/[controller]")]
    public class PlekkenController : ControllerBase
    {
        private readonly CampingContext _context;

        public PlekkenController(CampingContext context)
        {
            _context = context;
        }

        // GET: api/Plekken
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Plek>>> GetAll()
        {
            return await _context.Plekken.ToListAsync();
        }

        // GET: api/Plekken/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Plek>> GetById(int id)
        {
            var plek = await _context.Plekken
                .FirstOrDefaultAsync(p => p.PlekNummerID == id);

            if (plek == null)
                return NotFound();

            return plek;
        }

        // POST: api/Plekken
        [HttpPost]
        public async Task<ActionResult<Plek>> Create(Plek plek)
        {
            _context.Plekken.Add(plek);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(GetById),
                new { id = plek.PlekNummerID },
                plek
            );
        }

        // PUT: api/Plekken/5
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, Plek plek)
        {
            if (id != plek.PlekNummerID)
                return BadRequest();

            _context.Entry(plek).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PlekExists(id))
                    return NotFound();

                throw;
            }

            return NoContent();
        }

        // DELETE: api/Plekken/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var plek = await _context.Plekken.FindAsync(id);

            if (plek == null)
                return NotFound();

            _context.Plekken.Remove(plek);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool PlekExists(int id)
        {
            return _context.Plekken.Any(e => e.PlekNummerID == id);
        }
    }
}
