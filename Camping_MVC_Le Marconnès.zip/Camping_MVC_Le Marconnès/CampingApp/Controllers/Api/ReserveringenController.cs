﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CampingApp.Data;
using CampingApp.Models;

namespace CampingApp.Controllers.Api;

[ApiController]
[Route("api/[controller]")]
public class ReserveringenController : ControllerBase
{
    private readonly CampingContext _context;

    public ReserveringenController(CampingContext context)
    {
        _context = context;
    }

    // GET: api/Reserveringen
    [HttpGet]
    public async Task<ActionResult<IEnumerable<CampingApp.Models.Reservering>>> GetAll()
    {
        return await _context.Reserveringen.ToListAsync();
    }

    // GET: api/Reserveringen/5
    [HttpGet("{id}")]
    public async Task<ActionResult<CampingApp.Models.Reservering>> GetById(int id)
    {
        var reservering = await _context.Reserveringen.FindAsync(id);

        if (reservering == null)
            return NotFound();

        return Ok(reservering);
    }

    // POST: api/Reserveringen
    [HttpPost]
    public async Task<ActionResult<CampingApp.Models.Reservering>> Create([FromBody] CampingApp.Models.Reservering reservering)
    {
        _context.Reserveringen.Add(reservering);
        await _context.SaveChangesAsync();

        return CreatedAtAction(
            nameof(GetById),
            new { id = reservering.Id },
            reservering
        );
    }

    // PUT: api/Reserveringen/5
    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, [FromBody] CampingApp.Models.Reservering reservering)
    {
        if (id != reservering.Id)
            return BadRequest();

        _context.Entry(reservering).State = EntityState.Modified;
        await _context.SaveChangesAsync();

        return NoContent();
    }

    // DELETE: api/Reserveringen/5
    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var reservering = await _context.Reserveringen.FindAsync(id);

        if (reservering == null)
            return NotFound();

        _context.Reserveringen.Remove(reservering);
        await _context.SaveChangesAsync();

        return NoContent();
    }
}
