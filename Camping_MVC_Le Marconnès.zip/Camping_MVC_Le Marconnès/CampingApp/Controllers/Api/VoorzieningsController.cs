﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CampingApp.Data;
using CampingApp.Models;

namespace CampingApp.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    public class VoorzieningsController : ControllerBase
    {
        private readonly CampingContext _context;

        public VoorzieningsController(CampingContext context)
        {
            _context = context;
        }

        // GET: api/Voorzienings
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Voorziening>>> GetVoorzieningen()
        {
            return await _context.Voorzieningen.ToListAsync();
        }

        // GET: api/Voorzienings/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Voorziening>> GetVoorziening(int id)
        {
            var voorziening = await _context.Voorzieningen.FindAsync(id);

            if (voorziening == null)
            {
                return NotFound();
            }

            return voorziening;
        }

        // POST: api/Voorzienings
        [HttpPost]
        public async Task<ActionResult<Voorziening>> CreateVoorziening(Voorziening voorziening)
        {
            _context.Voorzieningen.Add(voorziening);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetVoorziening), new { id = voorziening.VoorzieningId }, voorziening);
        }

        // PUT: api/Voorzienings/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateVoorziening(int id, Voorziening voorziening)
        {
            if (id != voorziening.VoorzieningId)
            {
                return BadRequest();
            }

            _context.Entry(voorziening).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!VoorzieningExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: api/Voorzienings/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteVoorziening(int id)
        {
            var voorziening = await _context.Voorzieningen.FindAsync(id);
            if (voorziening == null)
            {
                return NotFound();
            }

            _context.Voorzieningen.Remove(voorziening);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool VoorzieningExists(int id)
        {
            return _context.Voorzieningen.Any(e => e.VoorzieningId == id);
        }
    }
}

