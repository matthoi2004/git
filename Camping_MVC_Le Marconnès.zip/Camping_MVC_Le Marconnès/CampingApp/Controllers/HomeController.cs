﻿using Microsoft.AspNetCore.Mvc;

namespace CampingApp.Controllers;

public class HomeController : Controller
{
    public IActionResult Index()
    {
        return View();
    }
}
