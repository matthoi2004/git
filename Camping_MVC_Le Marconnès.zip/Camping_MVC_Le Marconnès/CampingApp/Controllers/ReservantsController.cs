﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CampingApp.Data;
using CampingApp.Models;

namespace CampingApp.Controllers
{
    public class ReservantenController : Controller
    {
        private readonly CampingContext _context;

        public ReservantenController(CampingContext context)
        {
            _context = context;
        }

        // GET: Reservanten
        public async Task<IActionResult> Index()
        {
            return View(await _context.Reservanten.ToListAsync());
        }

        // GET: Reservanten/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var reservant = await _context.Reservanten
                .FirstOrDefaultAsync(m => m.ReservantId == id);
            if (reservant == null) return NotFound();

            return View(reservant);
        }

        // GET: Reservanten/Create
        public IActionResult Create() => View();

        // POST: Reservanten/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Naam")] Reservant reservant)
        {
            if (ModelState.IsValid)
            {
                _context.Add(reservant);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(reservant);
        }

        // GET: Reservanten/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var reservant = await _context.Reservanten.FindAsync(id);
            if (reservant == null) return NotFound();

            return View(reservant);
        }

        // POST: Reservanten/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Naam")] Reservant reservant)
        {
            var existingReservant = await _context.Reservanten.FindAsync(id);
            if (existingReservant == null) return NotFound();

            if (ModelState.IsValid)
            {
                // Update alleen de Naam
                existingReservant.Naam = reservant.Naam;

                try
                {
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (_context.Reservanten.Any(e => e.ReservantId == id))
                        throw;
                    else
                        return NotFound();
                }

                return RedirectToAction(nameof(Index));
            }

            return View(reservant);
        }

        // GET: Reservanten/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var reservant = await _context.Reservanten
                .FirstOrDefaultAsync(m => m.ReservantId == id);
            if (reservant == null) return NotFound();

            return View(reservant);
        }

        // POST: Reservanten/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var reservant = await _context.Reservanten.FindAsync(id);
            if (reservant != null)
            {
                _context.Reservanten.Remove(reservant);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        private bool ReservantExists(int id) =>
            _context.Reservanten.Any(e => e.ReservantId == id);
    }
}
