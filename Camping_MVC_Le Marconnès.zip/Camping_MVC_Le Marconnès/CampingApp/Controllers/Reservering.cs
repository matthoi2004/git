﻿namespace CampingApp.Controllers
{
    public class Reservering
    {
        public object ReservantId { get; internal set; }
        public int ReserveringId { get; internal set; }
    }
}