using Microsoft.EntityFrameworkCore;
using CampingApp.Models;

namespace CampingApp.Data
{
    public class CampingContext : DbContext
    {
        public CampingContext(DbContextOptions<CampingContext> options)
            : base(options) { }

        public DbSet<Reservant> Reservanten => Set<Reservant>();
        public DbSet<Reservering> Reserveringen => Set<Reservering>();
        public DbSet<Factuur> Facturen => Set<Factuur>();
        public DbSet<Betaling> Betalingen => Set<Betaling>();
        public DbSet<Plek> Plekken => Set<Plek>();
        public DbSet<Voorziening> Voorzieningen => Set<Voorziening>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Reservant>().HasKey(r => r.ReservantId);
            modelBuilder.Entity<Factuur>().HasKey(f => f.FactuurNummerID);
            modelBuilder.Entity<Plek>().HasKey(p => p.PlekNummerID);

            base.OnModelCreating(modelBuilder);
        }
    }
}
