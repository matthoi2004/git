﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CampingApp.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Betalingen",
                columns: table => new
                {
                    BetalingId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Datum = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Bedrag = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Betaalwijze = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Betalingen", x => x.BetalingId);
                });

            migrationBuilder.CreateTable(
                name: "Facturen",
                columns: table => new
                {
                    FactuurNummerID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TotaalBedrag = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    IsBetaald = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Facturen", x => x.FactuurNummerID);
                });

            migrationBuilder.CreateTable(
                name: "Plekken",
                columns: table => new
                {
                    PlekNummerID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PrijsPerNacht = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    MaxPersonen = table.Column<int>(type: "int", nullable: false),
                    OvernachtingsType = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Plekken", x => x.PlekNummerID);
                });

            migrationBuilder.CreateTable(
                name: "Reservanten",
                columns: table => new
                {
                    ReservantId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Naam = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Reservanten", x => x.ReservantId);
                });

            migrationBuilder.CreateTable(
                name: "Voorzieningen",
                columns: table => new
                {
                    VoorzieningId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Naam = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Voorzieningen", x => x.VoorzieningId);
                });

            migrationBuilder.CreateTable(
                name: "Reserveringen",
                columns: table => new
                {
                    ReserveringId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StartDatum = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ReservantId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Reserveringen", x => x.ReserveringId);
                    table.ForeignKey(
                        name: "FK_Reserveringen_Reservanten_ReservantId",
                        column: x => x.ReservantId,
                        principalTable: "Reservanten",
                        principalColumn: "ReservantId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Reserveringen_ReservantId",
                table: "Reserveringen",
                column: "ReservantId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Betalingen");

            migrationBuilder.DropTable(
                name: "Facturen");

            migrationBuilder.DropTable(
                name: "Plekken");

            migrationBuilder.DropTable(
                name: "Reserveringen");

            migrationBuilder.DropTable(
                name: "Voorzieningen");

            migrationBuilder.DropTable(
                name: "Reservanten");
        }
    }
}
