﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CampingApp.Models
{
    public class Betaling
    {
        public int BetalingId { get; set; }

        public DateTime Datum { get; set; }
        public decimal Bedrag { get; set; }

        public string Betaalwijze { get; set; } = null!;
    }
}
