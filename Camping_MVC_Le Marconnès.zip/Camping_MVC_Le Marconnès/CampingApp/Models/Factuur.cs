﻿using System.ComponentModel.DataAnnotations;

namespace CampingApp.Models
{
    public class Factuur
    {
        [Key]
        public int FactuurNummerID { get; set; }

        public decimal TotaalBedrag { get; set; }
        public bool IsBetaald { get; set; }

        public void Betalen()
        {
            IsBetaald = true;
        }
    }
}
