﻿using System.ComponentModel.DataAnnotations;

public class Plek
{
    [Key]
    public int PlekNummerID { get; set; }

    public decimal PrijsPerNacht { get; set; }
    public int MaxPersonen { get; set; }
    public string OvernachtingsType { get; set; }
}
