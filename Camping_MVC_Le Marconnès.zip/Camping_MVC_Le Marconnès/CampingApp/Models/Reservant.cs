namespace CampingApp.Models
{
    public class Reservant
    {
        public int ReservantId { get; set; }  // Primary key
        public string Naam { get; set; } = string.Empty;  // Non-nullable

        // Parameterloze constructor voor EF Core
        public Reservant() { }

        // Optionele constructor voor gemak
        public Reservant(string naam)
        {
            Naam = naam;
        }
    }
}
