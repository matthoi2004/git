using System;
using System.ComponentModel.DataAnnotations;

namespace CampingApp.Models
{
    public class Reservering
    {
        [Key]
        public int Id { get; set; }

        public DateTime StartDatum { get; set; }

        // Foreign key
        public int ReservantId { get; set; }

        // Navigatieproperty
        public Reservant Reservant { get; set; } = null!;
    }
}
