﻿using System.ComponentModel.DataAnnotations;

namespace CampingApp.Models
{
    public class Voorziening
    {
        public int VoorzieningId { get; set; }

        public string Naam { get; set; } = null!;
    }
}
