﻿using CampingApp.Data;
using Microsoft.EntityFrameworkCore;
using Swashbuckle.AspNetCore.SwaggerUI;
using Swashbuckle.AspNetCore.SwaggerGen;

var builder = WebApplication.CreateBuilder(args);

//
// 1️⃣ Services
//

// MVC + API controllers
builder.Services.AddControllersWithViews();
builder.Services.AddControllers();

// Entity Framework Core
builder.Services.AddDbContext<CampingContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection")));

// Swagger (voor API)
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();


//
// 2️⃣ Build app
//
var app = builder.Build();


//
// 3️⃣ Middleware
//
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(); // This now works because the required using directives are present
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();


//
// 4️⃣ Endpoints
//

// API endpoints
app.MapControllers();

// MVC routing
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");


//
// 5️⃣ Run
//
app.Run();
