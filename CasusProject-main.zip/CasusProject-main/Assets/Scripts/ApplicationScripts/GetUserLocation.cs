using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UnityEngine.Networking;
using System.Collections;
using UnityEngine.Android;
using UnityEngine.SceneManagement;

public class GetUserLocation : MonoBehaviour
{
    public RawImage mapImage;

    private string mapUrl = "https://api.mapbox.com/styles/v1/mapbox/streets-v11/static/pin-s-l+000({0},{1})/{0},{1},14,0/600x300?access_token=";
    
    void OnEnable()
    {
        // On startup request for location access.
        if (!Permission.HasUserAuthorizedPermission(Permission.FineLocation))
        {
            Permission.RequestUserPermission(Permission.FineLocation);
            Permission.RequestUserPermission(Permission.Camera);
        }
    }
    
    void Start()
    {
        StartCoroutine(GetLocation());
        Input.location.Start();
    }

    IEnumerator GetLocation()
    {
        int maxWait = 20;
        while (Input.location.status == LocationServiceStatus.Initializing && maxWait > 0)
        {
            yield return new WaitForSeconds(1);
            maxWait--;
        }

        if (maxWait <= 0)
        {
            yield break;
        }

        else
        {
            float latitude = Input.location.lastData.latitude;
            float longitude = Input.location.lastData.longitude;

            StartCoroutine(LoadMap(latitude, longitude));
            StartCoroutine(UpdateLocation());
        }
    }

    IEnumerator LoadMap(float latitude, float longitude)
    {
        string url = string.Format(mapUrl, longitude, latitude);
        UnityWebRequest request = UnityWebRequestTexture.GetTexture(url);
        yield return request.SendWebRequest();

        if (request.result == UnityWebRequest.Result.Success)
        {
            mapImage.texture = ((DownloadHandlerTexture)request.downloadHandler).texture;
        }
    }

    IEnumerator UpdateLocation()
    {
        while (true)
        {
            yield return new WaitForSeconds(3);
            if (Input.location.status == LocationServiceStatus.Running)
            {
                float latitude = Input.location.lastData.latitude;
                float longitude = Input.location.lastData.longitude;
                StartCoroutine(LoadMap(latitude, longitude));
            }
        }
    }
}
