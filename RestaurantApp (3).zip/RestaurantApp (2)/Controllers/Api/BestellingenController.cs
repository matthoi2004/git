
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RestaurantApp.Data;
using RestaurantApp.Models;
using System.Threading.Tasks;
using System.Linq;

namespace RestaurantApp.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    public class BestellingenController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        public BestellingenController(ApplicationDbContext context) => _context = context;

        [HttpGet]
        public async Task<IActionResult> GetAll() => Ok(await _context.Set<Bestelling>().ToListAsync());

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var item = await _context.Set<Bestelling>().FindAsync(id);
            if (item == null) return NotFound();
            return Ok(item);
        }

        [HttpPost]
        public async Task<IActionResult> Create(Bestelling input)
        {
            _context.Set<Bestelling>().Add(input);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(Get), new { id = (input).Id }, input);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, Bestelling input)
        {
            if (id != input.Id) return BadRequest();
            _context.Entry(input).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var item = await _context.Set<Bestelling>().FindAsync(id);
            if (item == null) return NotFound();
            _context.Set<Bestelling>().Remove(item);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
