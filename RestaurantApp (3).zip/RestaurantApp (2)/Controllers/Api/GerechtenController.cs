
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RestaurantApp.Data;
using RestaurantApp.Models;
using System.Threading.Tasks;
using System.Linq;

namespace RestaurantApp.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    public class GerechtenController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        public GerechtenController(ApplicationDbContext context) => _context = context;

        [HttpGet]
        public async Task<IActionResult> GetAll() => Ok(await _context.Set<Gerecht>().ToListAsync());

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var item = await _context.Set<Gerecht>().FindAsync(id);
            if (item == null) return NotFound();
            return Ok(item);
        }

        [HttpPost]
        public async Task<IActionResult> Create(Gerecht input)
        {
            _context.Set<Gerecht>().Add(input);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(Get), new { id = (input).Id }, input);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, Gerecht input)
        {
            if (id != input.Id) return BadRequest();
            _context.Entry(input).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var item = await _context.Set<Gerecht>().FindAsync(id);
            if (item == null) return NotFound();
            _context.Set<Gerecht>().Remove(item);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
