using Microsoft.AspNetCore.Mvc;

namespace RestaurantApp.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}

