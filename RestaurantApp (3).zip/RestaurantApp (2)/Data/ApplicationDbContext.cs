using Microsoft.EntityFrameworkCore;
using RestaurantApp.Models;

namespace RestaurantApp.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<MenuCategorie> MenuCategorieen { get; set; }
        public DbSet<Gerecht> Gerechten { get; set; }
        public DbSet<Bestelling> Bestellingen { get; set; }
        public DbSet<BestelRegel> BestelRegels { get; set; }
        public DbSet<Medewerker> Medewerkers { get; set; }
        public DbSet<Betaling> Betalingen { get; set; }
        public DbSet<Rekening> Rekeningen { get; set; }
        public DbSet<RestaurantBezoek> RestaurantBezoeken { get; set; }
        public DbSet<Tafel> Tafels { get; set; }
        public DbSet<TafelBezetting> TafelBezettingen { get; set; }
        public DbSet<AccommodatieReservering> AccommodatieReserveringen { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Example: composite or more advanced configs can go here
            modelBuilder.Entity<MenuCategorie>().ToTable("MenuCategorie").HasKey(m => m.Id);
        }
    }
}
