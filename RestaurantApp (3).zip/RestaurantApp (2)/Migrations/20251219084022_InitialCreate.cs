﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RestaurantApp.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AccommodatieReserveringen",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ReserveringsCode = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AccommodatieReserveringen", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Medewerkers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Naam = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Medewerkers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "MenuCategorie",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Naam = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MenuCategorie", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tafels",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nummer = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Zitplaatsen = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tafels", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "RestaurantBezoeken",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AccommodatieReserveringId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RestaurantBezoeken", x => x.Id);
                    table.ForeignKey(
                        name: "FK_RestaurantBezoeken_AccommodatieReserveringen_AccommodatieReserveringId",
                        column: x => x.AccommodatieReserveringId,
                        principalTable: "AccommodatieReserveringen",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Gerechten",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Naam = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Prijs = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    MenuCategorieId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Gerechten", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Gerechten_MenuCategorie_MenuCategorieId",
                        column: x => x.MenuCategorieId,
                        principalTable: "MenuCategorie",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Bestellingen",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MedewerkerId = table.Column<int>(type: "int", nullable: true),
                    RestaurantBezoekId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Bestellingen", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Bestellingen_Medewerkers_MedewerkerId",
                        column: x => x.MedewerkerId,
                        principalTable: "Medewerkers",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Bestellingen_RestaurantBezoeken_RestaurantBezoekId",
                        column: x => x.RestaurantBezoekId,
                        principalTable: "RestaurantBezoeken",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Rekeningen",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Totaal = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    RestaurantBezoekId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Rekeningen", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Rekeningen_RestaurantBezoeken_RestaurantBezoekId",
                        column: x => x.RestaurantBezoekId,
                        principalTable: "RestaurantBezoeken",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TafelBezettingen",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TafelId = table.Column<int>(type: "int", nullable: false),
                    RestaurantBezoekId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TafelBezettingen", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TafelBezettingen_RestaurantBezoeken_RestaurantBezoekId",
                        column: x => x.RestaurantBezoekId,
                        principalTable: "RestaurantBezoeken",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_TafelBezettingen_Tafels_TafelId",
                        column: x => x.TafelId,
                        principalTable: "Tafels",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "BestelRegels",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BestellingId = table.Column<int>(type: "int", nullable: false),
                    GerechtId = table.Column<int>(type: "int", nullable: false),
                    Aantal = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BestelRegels", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BestelRegels_Bestellingen_BestellingId",
                        column: x => x.BestellingId,
                        principalTable: "Bestellingen",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_BestelRegels_Gerechten_GerechtId",
                        column: x => x.GerechtId,
                        principalTable: "Gerechten",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Betalingen",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Bedrag = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    RekeningId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Betalingen", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Betalingen_Rekeningen_RekeningId",
                        column: x => x.RekeningId,
                        principalTable: "Rekeningen",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Bestellingen_MedewerkerId",
                table: "Bestellingen",
                column: "MedewerkerId");

            migrationBuilder.CreateIndex(
                name: "IX_Bestellingen_RestaurantBezoekId",
                table: "Bestellingen",
                column: "RestaurantBezoekId");

            migrationBuilder.CreateIndex(
                name: "IX_BestelRegels_BestellingId",
                table: "BestelRegels",
                column: "BestellingId");

            migrationBuilder.CreateIndex(
                name: "IX_BestelRegels_GerechtId",
                table: "BestelRegels",
                column: "GerechtId");

            migrationBuilder.CreateIndex(
                name: "IX_Betalingen_RekeningId",
                table: "Betalingen",
                column: "RekeningId");

            migrationBuilder.CreateIndex(
                name: "IX_Gerechten_MenuCategorieId",
                table: "Gerechten",
                column: "MenuCategorieId");

            migrationBuilder.CreateIndex(
                name: "IX_Rekeningen_RestaurantBezoekId",
                table: "Rekeningen",
                column: "RestaurantBezoekId");

            migrationBuilder.CreateIndex(
                name: "IX_RestaurantBezoeken_AccommodatieReserveringId",
                table: "RestaurantBezoeken",
                column: "AccommodatieReserveringId");

            migrationBuilder.CreateIndex(
                name: "IX_TafelBezettingen_RestaurantBezoekId",
                table: "TafelBezettingen",
                column: "RestaurantBezoekId");

            migrationBuilder.CreateIndex(
                name: "IX_TafelBezettingen_TafelId",
                table: "TafelBezettingen",
                column: "TafelId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BestelRegels");

            migrationBuilder.DropTable(
                name: "Betalingen");

            migrationBuilder.DropTable(
                name: "TafelBezettingen");

            migrationBuilder.DropTable(
                name: "Bestellingen");

            migrationBuilder.DropTable(
                name: "Gerechten");

            migrationBuilder.DropTable(
                name: "Rekeningen");

            migrationBuilder.DropTable(
                name: "Tafels");

            migrationBuilder.DropTable(
                name: "Medewerkers");

            migrationBuilder.DropTable(
                name: "MenuCategorie");

            migrationBuilder.DropTable(
                name: "RestaurantBezoeken");

            migrationBuilder.DropTable(
                name: "AccommodatieReserveringen");
        }
    }
}
