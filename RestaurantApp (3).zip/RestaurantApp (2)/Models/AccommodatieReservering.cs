
namespace RestaurantApp.Models
{
    public class AccommodatieReservering
    {
        public int Id { get; set; }
        public string ReserveringsCode { get; set; }
    }
}
