
namespace RestaurantApp.Models
{
    public class BestelRegel
    {
        public int Id { get; set; }

        public int BestellingId { get; set; }
        public Bestelling Bestelling { get; set; }

        public int GerechtId { get; set; }
        public Gerecht Gerecht { get; set; }

        public int Aantal { get; set; }
    }
}
