
using System.Collections.Generic;

namespace RestaurantApp.Models
{
    public class Bestelling
    {
        public int Id { get; set; }

        public int? MedewerkerId { get; set; }
        public Medewerker Medewerker { get; set; }

        public int? RestaurantBezoekId { get; set; }
        public RestaurantBezoek RestaurantBezoek { get; set; }

        public ICollection<BestelRegel> BestelRegels { get; set; }
    }
}
