
namespace RestaurantApp.Models
{
    public class Betaling
    {
        public int Id { get; set; }
        public decimal Bedrag { get; set; }

        public int RekeningId { get; set; }
        public Rekening Rekening { get; set; }
    }
}
