
namespace RestaurantApp.Models
{
    public class Gerecht
    {
        public int Id { get; set; }
        public string Naam { get; set; }
        public decimal Prijs { get; set; }

        public int MenuCategorieId { get; set; }
        public MenuCategorie MenuCategorie { get; set; }
    }
}
