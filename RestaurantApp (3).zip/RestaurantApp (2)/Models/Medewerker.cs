
namespace RestaurantApp.Models
{
    public class Medewerker
    {
        public int Id { get; set; }
        public string Naam { get; set; }
    }
}
