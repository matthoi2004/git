
using System.Collections.Generic;

namespace RestaurantApp.Models
{
    public class MenuCategorie
    {
        public int Id { get; set; }
        public string Naam { get; set; }

        public ICollection<Gerecht> Gerechten { get; set; }
    }
}
