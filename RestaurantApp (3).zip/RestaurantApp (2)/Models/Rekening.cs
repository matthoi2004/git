
using System.Collections.Generic;

namespace RestaurantApp.Models
{
    public class Rekening
    {
        public int Id { get; set; }
        public decimal Totaal { get; set; }

        public int RestaurantBezoekId { get; set; }
        public RestaurantBezoek RestaurantBezoek { get; set; }

        public ICollection<Betaling> Betalingen { get; set; }
    }
}
