
using System.Collections.Generic;

namespace RestaurantApp.Models
{
    public class RestaurantBezoek
    {
        public int Id { get; set; }

        public int? AccommodatieReserveringId { get; set; }
        public AccommodatieReservering AccommodatieReservering { get; set; }

        public ICollection<Bestelling> Bestellingen { get; set; }
        public ICollection<Rekening> Rekeningen { get; set; }
        public ICollection<TafelBezetting> TafelBezettingen { get; set; }
    }
}
