
namespace RestaurantApp.Models
{
    public class Tafel
    {
        public int Id { get; set; }
        public string Nummer { get; set; }
        public int Zitplaatsen { get; set; }
    }
}
