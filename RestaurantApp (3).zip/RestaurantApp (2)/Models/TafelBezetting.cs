
namespace RestaurantApp.Models
{
    public class TafelBezetting
    {
        public int Id { get; set; }

        public int TafelId { get; set; }
        public Tafel Tafel { get; set; }

        public int RestaurantBezoekId { get; set; }
        public RestaurantBezoek RestaurantBezoek { get; set; }
    }
}
