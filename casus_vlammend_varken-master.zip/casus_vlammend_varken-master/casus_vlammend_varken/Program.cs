﻿using System;
using MySql.Data.MySqlClient;

class Program
{
    static void Main()
    {
        string connectionString = "Server=74.234.163.46;Port=3306;Database=VlammendVarkenDB;User ID=root;Password=hetvlammendvarken1!;";

        using (MySqlConnection conn = new MySqlConnection(connectionString))
        {
            try
            {
                conn.Open();
                Console.WriteLine("✅ Verbinding met MySQL-server is gelukt!\n");

                Console.WriteLine("Kies een optie:");
                Console.WriteLine("1. Toon data");
                Console.WriteLine("2. Voeg gerecht toe");
                Console.WriteLine("3. Voeg ingrediënt toe");
                Console.Write("Jouw keuze: ");
                var keuze = Console.ReadLine();

                if (keuze == "1")
                {
                    ToonData(conn);
                }
                else if (keuze == "2")
                {
                    VoegGerechtToe(conn);
                }
                else if (keuze == "3")
                {
                    VoegIngredientToe(conn);
                }
                else
                {
                    Console.WriteLine("❌ Ongeldige keuze.");
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("❌ Fout bij verbinden of opvragen van data:");
                Console.WriteLine(ex.Message);
            }
        }

        Console.WriteLine("\nDruk op een toets om af te sluiten....");
        Console.ReadKey();
    }

    static void ToonData(MySqlConnection conn)
    {
        Console.WriteLine("🧾 Gerechten:");
        string queryGerechten = "SELECT GerechtID, Naam FROM Gerecht;";
        using (MySqlCommand cmd = new MySqlCommand(queryGerechten, conn))
        using (MySqlDataReader reader = cmd.ExecuteReader())
        {
            while (reader.Read())
            {
                Console.WriteLine($"  GerechtID: {reader["GerechtID"]}, Naam: {reader["Naam"]}");
            }
        }

        Console.WriteLine("\n🍴 Ingrediënten:");
        string queryIngrediënten = "SELECT IngrediëntID, Naam, Eenheid, Hoeveelheid, MinHoeveelheid FROM Ingrediënt;";
        using (MySqlCommand cmd = new MySqlCommand(queryIngrediënten, conn))
        using (MySqlDataReader reader = cmd.ExecuteReader())
        {
            while (reader.Read())
            {
                Console.WriteLine($"  IngrediëntID: {reader["IngrediëntID"]}, Naam: {reader["Naam"]}, Eenheid: {reader["Eenheid"]}, Hoeveelheid: {reader["Hoeveelheid"]}, MinHoeveelheid: {reader["MinHoeveelheid"]}");
            }
        }

        Console.WriteLine("\n🔗 Gerecht-Ingrediënt-koppelingen:");
        string queryKoppeling = @"
            SELECT 
                GI.GerechtID,
                G.Naam AS GerechtNaam,
                GI.IngrediëntID,
                I.Naam AS IngrediëntNaam,
                GI.HoeveelheidNodig
            FROM GerechtIngredient GI
            JOIN Gerecht G ON GI.GerechtID = G.GerechtID
            JOIN Ingrediënt I ON GI.IngrediëntID = I.IngrediëntID;";
        using (MySqlCommand cmd = new MySqlCommand(queryKoppeling, conn))
        using (MySqlDataReader reader = cmd.ExecuteReader())
        {
            while (reader.Read())
            {
                Console.WriteLine($"  {reader["GerechtNaam"]} bevat {reader["HoeveelheidNodig"]} {reader["IngrediëntNaam"]}");
            }
        }
    }

    static void VoegGerechtToe(MySqlConnection conn)
    {
        Console.Write("Voer naam van het nieuwe gerecht in: ");
        string gerechtNaam = Console.ReadLine();

        if (string.IsNullOrWhiteSpace(gerechtNaam))
        {
            Console.WriteLine("❌ Ongeldige naam. Geen gerecht toegevoegd.");
            return;
        }

        string insertQuery = "INSERT INTO Gerecht (Naam) VALUES (@Naam); SELECT LAST_INSERT_ID();";
        using (MySqlCommand cmd = new MySqlCommand(insertQuery, conn))
        {
            cmd.Parameters.AddWithValue("@Naam", gerechtNaam);
            long gerechtID = Convert.ToInt64(cmd.ExecuteScalar());

            if (gerechtID > 0)
            {
                Console.WriteLine($"✅ Gerecht '{gerechtNaam}' succesvol toegevoegd met ID {gerechtID}.");
                KoppelIngredienten(conn, gerechtID);
            }
            else
            {
                Console.WriteLine("❌ Toevoegen mislukt.");
            }
        }
    }

    static void VoegIngredientToe(MySqlConnection conn)
    {
        Console.Write("Naam van ingrediënt: ");
        string naam = Console.ReadLine();

        Console.Write("Eenheid (bijv. gram, liter): ");
        string eenheid = Console.ReadLine();

        Console.Write("Hoeveelheid: ");
        if (!decimal.TryParse(Console.ReadLine(), out decimal hoeveelheid))
        {
            Console.WriteLine("❌ Ongeldige hoeveelheid.");
            return;
        }

        Console.Write("Minimale hoeveelheid: ");
        if (!decimal.TryParse(Console.ReadLine(), out decimal minHoeveelheid))
        {
            Console.WriteLine("❌ Ongeldige minimale hoeveelheid.");
            return;
        }

        string insertQuery = "INSERT INTO Ingrediënt (Naam, Eenheid, Hoeveelheid, MinHoeveelheid) VALUES (@Naam, @Eenheid, @Hoeveelheid, @MinHoeveelheid);";
        using (MySqlCommand cmd = new MySqlCommand(insertQuery, conn))
        {
            cmd.Parameters.AddWithValue("@Naam", naam);
            cmd.Parameters.AddWithValue("@Eenheid", eenheid);
            cmd.Parameters.AddWithValue("@Hoeveelheid", hoeveelheid);
            cmd.Parameters.AddWithValue("@MinHoeveelheid", minHoeveelheid);

            int result = cmd.ExecuteNonQuery();

            if (result > 0)
                Console.WriteLine("✅ Ingrediënt succesvol toegevoegd.");
            else
                Console.WriteLine("❌ Toevoegen mislukt.");
        }
    }

    static void KoppelIngredienten(MySqlConnection conn, long gerechtID)
    {
        Console.WriteLine("\n📋 Beschikbare ingrediënten:");
        string query = "SELECT IngrediëntID, Naam FROM Ingrediënt;";
        using (MySqlCommand cmd = new MySqlCommand(query, conn))
        using (MySqlDataReader reader = cmd.ExecuteReader())
        {
            while (reader.Read())
            {
                Console.WriteLine($"  {reader["IngrediëntID"]}: {reader["Naam"]}");
            }
        }

        while (true)
        {
            Console.Write("Voer IngrediëntID in (of 'klaar' om te stoppen): ");
            string input = Console.ReadLine();
            if (input.ToLower() == "klaar") break;

            if (!int.TryParse(input, out int ingrediëntID))
            {
                Console.WriteLine("❌ Ongeldige ID.");
                continue;
            }

            Console.Write("Hoeveelheid nodig: ");
            string hoeveelheidInput = Console.ReadLine();
            if (!decimal.TryParse(hoeveelheidInput, out decimal hoeveelheid))
            {
                Console.WriteLine("❌ Ongeldige hoeveelheid.");
                continue;
            }

            string insertRelatie = "INSERT INTO GerechtIngredient (GerechtID, IngrediëntID, HoeveelheidNodig) VALUES (@GerechtID, @IngrediëntID, @Hoeveelheid);";
            using (MySqlCommand cmd = new MySqlCommand(insertRelatie, conn))
            {
                cmd.Parameters.AddWithValue("@GerechtID", gerechtID);
                cmd.Parameters.AddWithValue("@IngrediëntID", ingrediëntID);
                cmd.Parameters.AddWithValue("@Hoeveelheid", hoeveelheid);
                cmd.ExecuteNonQuery();

                Console.WriteLine("✅ Ingrediënt gekoppeld.");
            }
        }
    }
} // Zorg ervoor dat je de MySql.Data NuGet package hebt toegevoegd aan je project